<?php

namespace App\Models\OfficeSetup;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KycOffice extends Model
{
    use HasFactory;
    protected $table="kycOfficeMaster";
}
